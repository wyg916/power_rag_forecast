# RAG-R1B OCR candidate review material

Open only after blind initial annotations are submitted and hashed. Candidates use the native PDF text layer and geometry only; no OCR/VLM model was invoked and no candidate is human gold.
