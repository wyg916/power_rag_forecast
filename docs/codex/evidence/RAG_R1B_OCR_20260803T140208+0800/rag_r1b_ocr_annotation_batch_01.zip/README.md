# RAG-R1B OCR blind annotation batch 01

This archive contains exactly 10 rendered source pages and empty human annotation forms.
Do not open the candidate review archive before the initial annotation is submitted and hashed.
Automatic/native PDF extraction is never human gold. Fill text, tables/cells, elements, page/bbox, digits, annotator and timestamps; a different reviewer must verify all five checks.
